No Feature Processor has been created for this game - Get involved here!
https://github.com/fielddaylab/opengamedata
## Field Day Open Game Data 
### Retrieved from https://fielddaylab.wisc.edu/opengamedata 
### These anonymous data are provided in service of future educational data mining research. 
### They are made available under the Creative Commons CCO 1.0 Universal license. 
### See https://creativecommons.org/publicdomain/zero/1.0/ 

## Suggested citation: 
### Field Day. (2019). Open Educational Game Play Logs - [dataset ID]. Retrieved [today's date] from https://fielddaylab.wisc.edu/opengamedata 

## Game: BACTERIA 

## Field Descriptions: 
### Raw CSV Columns:
id - Unique identifier for a row
app_id - A string identifying which game from which the event came
app_id_fast - A second version of the app id, to be removed
app_version - The version of the game from which the event came
session_id - Unique identifier for the gameplay session
persistent_session_id - Unique identifier across all gameplay sessions from a single computer
player_id - A custom, per-player ID, only exists if player entered an ID on one of our custom portal pages, else null
level - The game level in which the event was logged
event - The type of event logged
event_custom - A number corresponding to the game-specific event type for events labeled 'Custom'
event_data_simple - Unused (always=0), to be deleted
event_data_complex - Data specific to an event type, encoded as a JSON string
client_time - The client machine time when the event was generated
client_time_ms - Client time in milliseconds
server_time - The server machine time when the event was logged
remote_addr - The IP address for the player's computer
req_id - Another ID of some kind, to be removed
session_n - Counter of events in the session, from 0. A row with session_n = i is the (i+1)-th event of the session
http_user_agent - Data on the type of web browser, OS, etc. in use by the player

### Processed Features:


## Global Database Changelog:
### July 2019:
- Crystal game data now includes Menu Button events.
### August 2019:
- Added remote_addr field to raw csv
- Duplicated events may exist in data prior to August 21, 2019.